package com.atc.online.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.atc.online.common.BasePage;
import com.atc.online.utils.PropertiesLoader;


public class LoginPage extends BasePage {

	public LoginPage(WebDriver selenium){
		super(selenium);
		initialize(this);
	}


	public void loginCredential() throws IOException, InterruptedException

	{
		PropertiesLoader prop = new PropertiesLoader();
		BasePage.getDriver().get((String)prop.loadBaseProperties().get("url"));	
		//boolean submitbuttonPresence = selenium.findElement(By.name("txtusername")).isDisplayed();
		//System.out.println(submitbuttonPresence);
		selenium.findElement(By.name("txtusername")).sendKeys(prop.loadBaseProperties().getProperty("username"));
		selenium.findElement(By.name("txtpassword")).sendKeys(prop.loadBaseProperties().getProperty("password"));
		selenium.findElement(By.name("Submit")).click();
		System.out.println(" " + "Sucessful login to Online Application");

	}

}	

