package com.atc.online.common;


import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.atc.online.utils.ExcelUtils;
import com.atc.online.utils.PropertiesLoader;


public class BasePage {

	protected static WebDriver selenium;

	public BasePage(WebDriver selenium){
		BasePage.selenium = selenium;
	}

	public void initialize(Object o){
		PageFactory.initElements(selenium, o);
	}

	public synchronized static WebDriver getDriver() throws IOException {

		PropertiesLoader prop = new PropertiesLoader();
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("test-type","--start-maximized");
		capabilities.setCapability("chrome.binary", prop.loadBaseProperties().getProperty("ChromeDriver"));
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		if (System.getProperty("executionEnv") == null) {

			System.setProperty("webdriver.chrome.driver", prop.loadBaseProperties().getProperty("ChromeDriver"));	

			if (selenium == null) {
				selenium = new ChromeDriver(capabilities);
			}

		}

		return selenium;
	}

	public static synchronized WebDriverWait getWebDriverWait(int waitMilliSeconds) {
		WebDriverWait wait = new WebDriverWait(selenium, waitMilliSeconds);
		return wait;
	}

	public static String getdata(String sheetname, String testcaseID,String columnname) throws Exception {
		ExcelUtils ExcelUtil = new ExcelUtils();
		ExcelUtil.setExcelFile(sheetname);
		String val = ExcelUtil.getCellData(testcaseID, columnname).get(testcaseID);
		return val;
	}

}
