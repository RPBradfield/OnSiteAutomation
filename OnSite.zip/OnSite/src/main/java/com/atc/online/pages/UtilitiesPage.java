package com.atc.online.pages;

import com.atc.online.common.BasePage;
import com.sun.xml.internal.ws.client.sei.ResponseBuilder;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 * Created by Richard.Bradfield on 8/19/2016.
 */
public class UtilitiesPage extends BasePage {

    public UtilitiesPage (WebDriver selenium) {
        super(selenium);
        initialize(this);
    }

    @FindBy(Header
    WebElement ATCServicePower_Header;

    public String ATCServicePower_Header() {
        BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.css(".tab-title>h4")));
        String ATCServicePower_Header = (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.css("ATCServicePower_Header")));
        return ATCServicePower_Header;
    }

}
