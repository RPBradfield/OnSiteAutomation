package com.atc.online.utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBQuery {

	public ResultSet DI(String query) throws SQLException {

		DBConnection c = new DBConnection();
		Connection conn = c.DIconnect();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		rs.next();
		return rs;
	}

	public ResultSet FMW(String query) throws SQLException {

		DBConnection c = new DBConnection();
		Connection conn = c.FMWconnect();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		rs.next();
		return rs;
	}
}
