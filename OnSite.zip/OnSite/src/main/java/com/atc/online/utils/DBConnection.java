package com.atc.online.utils;


import java.sql.*;

public class DBConnection {
	static Connection conn = null;
	static String oracle_driverName = null;

	public Connection DIconnect() throws SQLException {
		try {
			PropertiesLoader PropertiesLoader = new PropertiesLoader();
			oracle_driverName = "oracle.jdbc.driver.OracleDriver";
			Class.forName(oracle_driverName);
			conn = DriverManager.getConnection
					(
							PropertiesLoader.loadBaseProperties().getProperty("di.oracle.DB.url")
							+ PropertiesLoader.loadBaseProperties().getProperty("di.oracle.host")
							+ ":"
							+ PropertiesLoader.loadBaseProperties().getProperty("di.oracle.port")
							+ ":"
							+ PropertiesLoader.loadBaseProperties().getProperty("di.oracle.database"),
							PropertiesLoader.loadBaseProperties().getProperty("di.oracle.username"),
							PropertiesLoader.loadBaseProperties().getProperty(
									"di.oracle.password"));
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
			conn.close();
		}
		return conn;
	}


	public Connection FMWconnect() throws SQLException {
		try {
			PropertiesLoader PropertiesLoader = new PropertiesLoader();
			oracle_driverName = "oracle.jdbc.driver.OracleDriver";
			Class.forName(oracle_driverName);
			conn = DriverManager.getConnection
					(
							PropertiesLoader.loadBaseProperties().getProperty("fmw.oracle.DB.url")
							+ PropertiesLoader.loadBaseProperties().getProperty("fmw.oracle.host")
							+ ":"
							+ PropertiesLoader.loadBaseProperties().getProperty("fmw.oracle.port")
							+ ":"
							+ PropertiesLoader.loadBaseProperties().getProperty("fmw.oracle.database"),
							PropertiesLoader.loadBaseProperties().getProperty("fmw.oracle.username"),
							PropertiesLoader.loadBaseProperties().getProperty(
									"fmw.oracle.password"));
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
			conn.close();
		}
		return conn;
	}


	//	public static void main(String[] args) throws SQLException{
	//		DBConnection c = new DBConnection();
	//
	//		try{
	//
	//			Connection conn = c.DIQCconnect();
	//			Statement stmt = conn.createStatement();
	//			ResultSet rs = stmt.executeQuery("select PROJECT_NAME,PROJECT_TEMPLATE_NAME,WORKFLOW_TYPE from US_ODS.PROJECT where PROJECT_NUMBER= '11691357'");
	//			while (rs.next()) {
	//				String PROJECT_NAME = rs.getString("PROJECT_NAME");
	//				String PROJECT_TEMPLATE_NAME = rs.getString("PROJECT_TEMPLATE_NAME");
	//				String WORKFLOW_TYPE = rs.getString("WORKFLOW_TYPE");
	//				System.out.println(PROJECT_NAME + "\t" + PROJECT_TEMPLATE_NAME +"\t" + WORKFLOW_TYPE);
	//			}
	//		} 
	//		finally{
	//			conn.close(); 
	//		}
	//	}




}