package com.atc.online.utils;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;

public class ExcelUtils {

	private XSSFSheet sheet;
	private XSSFWorkbook workBook;

	HashMap<String, String> properties = new HashMap<String, String>();

	public void setExcelFile(String SheetName) throws Exception {

		try {
			PropertiesLoader PropertiesLoader = new PropertiesLoader();
			String Path=(String) PropertiesLoader.loadBaseProperties().get("onlineAppExcelData");
			workBook = new XSSFWorkbook(Path);
			sheet = workBook.getSheet(SheetName);
		} catch (Exception e) {

			throw (e);

		}

	}

	// Read data using Hashmap
	public HashMap<String, String> getCellData(String TestCaseID,String ColumnName)

			throws Exception {

		try {
			XSSFCell cell1 = null;
			XSSFCell cell2 = null;
			XSSFCell cell3 = null;

			Row firstRow = sheet.getRow(0);
			for (Cell cell : firstRow) {
				if (cell.getStringCellValue().equals(ColumnName)) {
					Iterator rowIterator = sheet.rowIterator();
					while (rowIterator.hasNext()) {
						XSSFRow row = (XSSFRow) rowIterator.next();
						Iterator cellIterator =row.cellIterator();
						cell1 = (XSSFCell) cellIterator.next();
						String key = formatData(cell1);
						if (key.equals(TestCaseID)) {
							if (cell.getStringCellValue().equals(ColumnName)) {
								int index = cell.getColumnIndex();
								int k = index;
								if (index == 1) {
									cell2 = (XSSFCell) cellIterator.next();
									String value = formatData(cell2);
									properties.put(key,value);
									return properties;
								}
								for (int i = 2; i <= index; i++) {
									cell2 = (XSSFCell)
											cellIterator.next();
									int j = i;
									if (j == k) {
										cell3 =(XSSFCell) cellIterator.next();
										String value = formatData(cell3);
										properties.put(key,value);
										return properties;
									}
								}
							}
						}
					}
				}
			}
		}

		catch (Exception e) {
			throw (e);
		}
		return properties;
	}

	public String formatData(XSSFCell value) {
		String newValue = null;
		if (value.getCellType() == 0) {
			if (DateUtil.isCellDateFormatted(value)) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
				String formatedDate = dateFormat.format(value.getDateCellValue());
				return formatedDate;
			}
			else {
				long getvalue = (long) value.getNumericCellValue();
				String newValue1 =String.valueOf(getvalue);
				return newValue1;
			}

		}
		if (value.getCellType() == 1) {
			String varvalue = value.getStringCellValue();
			return varvalue;
		}
		return newValue;

	}
}