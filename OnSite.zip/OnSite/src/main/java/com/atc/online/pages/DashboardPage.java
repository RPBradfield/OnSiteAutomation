package com.atc.online.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.atc.online.common.BasePage;


public class DashboardPage extends BasePage {

	public DashboardPage (WebDriver selenium) {
		super(selenium);
		initialize(this);
	}

	@FindBy(css ="html body div#page-wrapper div.container-box fieldset#searchcriteria_Fs table#tblSearchCriteria tbody tr td input")
	WebElement searchText_Box;

	public WebElement getSearchText_Box() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOf(searchText_Box));
		return searchText_Box;
	}

	public void setSearchText_Box(WebElement searchText_Box) {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOf(searchText_Box));
		this.searchText_Box = searchText_Box;
	}

	@FindBy(id ="user-id")
	WebElement logout;

	public WebElement getLogout() {
		BasePage.getWebDriverWait(10000).until(ExpectedConditions.visibilityOf(logout));
		return logout;
	}

	public void setLogout(WebElement logout) {
		this.logout = logout;
	}

	@FindBy(id ="search")
	WebElement search_btn;

	public WebElement getSearch_btn() {
		BasePage.getWebDriverWait(10000).until(ExpectedConditions.visibilityOf(search_btn));
		return search_btn;
	}

	public void setSearch_btn(WebElement search_btn) {
		this.search_btn = search_btn;
	}

	@FindBy(id ="clearData")
	WebElement clear_btn;

	public WebElement getClear_btn() {
		BasePage.getWebDriverWait(10000).until(ExpectedConditions.elementToBeClickable(clear_btn));
		return clear_btn;
	}

	public void setClear_btn(WebElement clear_btn) {
		BasePage.getWebDriverWait(10000).until(ExpectedConditions.elementToBeClickable(clear_btn));
		this.clear_btn = clear_btn;
	}

	@FindBy(name ="siteselectOff")
	WebElement select_checkbox;

	public WebElement getSelect_checkbox() {
		BasePage.getWebDriverWait(10000).until(ExpectedConditions.visibilityOf(select_checkbox));
		return select_checkbox;
	}

	public void setSelect_checkbox(WebElement select_checkbox) {
		this.select_checkbox = select_checkbox;
	}

	@FindBy(id ="savelocalB")
	WebElement saveSiteLocally;

	public WebElement getSaveSiteLocally() {
		BasePage.getWebDriverWait(10000).until(ExpectedConditions.visibilityOf(saveSiteLocally));
		return saveSiteLocally;
	}

	public void setSaveSiteLocally(WebElement saveSiteLocally) {
		this.saveSiteLocally = saveSiteLocally;
	}

	@FindBy(id ="page")
	WebElement clickSiteNumber_link;

	public WebElement getClickSiteNumber_link() {
		BasePage.getWebDriverWait(10000).until(ExpectedConditions.visibilityOf(clickSiteNumber_link));
		return clickSiteNumber_link;
	}

	public void setClickSiteNumber_link(WebElement clickSiteNumber_link) {
		this.clickSiteNumber_link = clickSiteNumber_link;
	}

	@FindBy(id ="dd-as")
	WebElement dashBoard_tab;

	public WebElement getDashBoard_tab() {
		BasePage.getWebDriverWait(10000).until(ExpectedConditions.visibilityOf(dashBoard_tab));
		return dashBoard_tab;
	}

	public void setDashBoard_tab(WebElement dashBoard_tab) {
		this.dashBoard_tab = dashBoard_tab;
	}

	@FindBy(id ="alert-modal")
	WebElement alert_popup;

	public WebElement getAlert_popup() {
		BasePage.getWebDriverWait(10000).until(ExpectedConditions.visibilityOf(alert_popup));
		return alert_popup;
	}

	public void setAlert_popup(WebElement alert_popup) {
		this.alert_popup = alert_popup;
	}

	@FindBy(id ="alert-button")
	WebElement alertOk_button;

	public WebElement getAlertOk_button() {
		BasePage.getWebDriverWait(10000).until(ExpectedConditions.visibilityOf(alertOk_button));
		return alertOk_button;
	}

	public void setAlertOk_button(WebElement alertOk_button) {
		this.alertOk_button = alertOk_button;
	}

	@FindBy(id ="job-safety-status")
	WebElement JobSafety_tab;

	public WebElement getJobSafety_tab() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOf(JobSafety_tab));
		return JobSafety_tab;
	}

	public void setJobSafety_tab(WebElement jobSafety_tab) {
		JobSafety_tab = jobSafety_tab;
	}

}





