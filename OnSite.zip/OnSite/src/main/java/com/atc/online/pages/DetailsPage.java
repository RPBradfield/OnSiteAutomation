package com.atc.online.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.atc.online.common.BasePage;

public class DetailsPage extends BasePage {

	public DetailsPage (WebDriver selenium) {
		super(selenium);
		initialize(this);
	}

	/* This Method Is for getting SiteNumber in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_SITE_NUMBER")
	WebElement siteNumber_txtbox;

	public String getSiteNumber_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_SITE_NUMBER")));
		String siteNumber_txtbox = (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_SITE_NUMBER")));
		return siteNumber_txtbox;
	}

	public void setSiteNumber_txtbox(WebElement siteNumber_txtbox) {
		this.siteNumber_txtbox = siteNumber_txtbox;
	}

	/* This Method Is for getting SiteNumber in Detail Page  End*/

	/* This Method Is for getting SiteName in Detail Page  Start*/

	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_SITE_NAME")
	WebElement siteName_txtbox;

	public String getSiteName_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_SITE_NAME")));
		String siteName_txtbox = (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_SITE_NAME")));
		return siteName_txtbox;
	}

	public void setSiteName_txtbox(WebElement siteName_txtbox) {

		this.siteName_txtbox= siteName_txtbox;
	}
	/* This Method Is for getting SiteName in Detail Page  End*/

	/* This Method Is for getting Address in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_SITE_ADDRESS")
	WebElement address_txtbox;

	public String getAddress_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_SITE_ADDRESS")));
		String Address_txtbox = (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_SITE_ADDRESS")));
		return Address_txtbox;
	}

	public void setAddress_txtbox(WebElement address_txtbox) {
		this.address_txtbox = address_txtbox;
	}
	/* This Method Is for getting Address in Detail Page  End*/

	/* This Method Is for getting City in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_CITY")
	WebElement city_txtbox;

	public String getCity_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_CITY")));
		String City_txtbox = (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_CITY")));
		return City_txtbox;
	}

	public void setCity_txtbox(WebElement city_txtbox) {
		this.city_txtbox= city_txtbox;
	}
	/* This Method Is for getting City in Detail Page  End*/

	/* This Method Is for getting State in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_STATE")
	WebElement state_txtbox;

	public String getState_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_STATE")));
		String State_txtbox = (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_STATE")));
		return State_txtbox;
	}

	public void setState_txtbox(WebElement state_txtbox) {
		this.state_txtbox = state_txtbox;
	}
	/* This Method Is for getting State in Detail Page  End*/

	/* This Method Is for getting zipcode in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_ZIP_CODE")
	WebElement zipcode_txtbox;

	public String getZipcode_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_ZIP_CODE")));
		String Zipcode_txtbox = (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_ZIP_CODE")));
		return Zipcode_txtbox;
	}

	public void setZipcode_txtbox(WebElement zipcode_txtbox) {
		this.zipcode_txtbox = zipcode_txtbox;
	}
	/* This Method Is for getting zipcode in Detail Page  End*/

	/* This Method Is for getting County in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_COUNTY")
	WebElement county_txtbox;

	public String getCounty_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_COUNTY")));
		String County_txtbox = (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_COUNTY")));
		return County_txtbox;
	}

	public void setCounty_txtbox(WebElement county_txtbox) {
		this.county_txtbox = county_txtbox;
	}
	/* This Method Is for getting County in Detail Page  End*/

	/* This Method Is for getting 911Address in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_ADDRESS_911")
	WebElement Address_911txtbox;

	public String getAddress_911txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_ADDRESS_911")));
		String Address_911txtbox = (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_ADDRESS_911")));
		return Address_911txtbox;
	}

	public void setAddress_911txtbox(WebElement address_911txtbox) {
		Address_911txtbox = address_911txtbox;
	}
	/* This Method Is for getting 911Address in Detail Page  End*/

	/* This Method Is for getting Text for Driving Directions field in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_DRIVING_DIRECTIONS")
	WebElement drivingDirections_txtbox;

	public String getDrivingDirections_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_DRIVING_DIRECTIONS")));
		String DrivingDirections_txtbox = (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_DRIVING_DIRECTIONS")));
		return DrivingDirections_txtbox;
	}

	public void setDrivingDirections_txtbox(WebElement drivingDirections_txtbox) {
		this.drivingDirections_txtbox = drivingDirections_txtbox;
	}
	/* This Method Is for getting Driving Directions in Detail Page  End*/

	/* This Method Is for sending Driving Directions in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_DRIVING_DIRECTIONS")
	WebElement drivingDirections_write;

	public WebElement getDrivingDirections_write() {
		return drivingDirections_write;
	}
	public void setDrivingDirections_write(WebElement drivingDirections_write) {
		this.drivingDirections_write = drivingDirections_write;
	}
	/* This Method Is for sending Driving Directions in Detail Page  End*/

	/* This Method Is for getting SiteAccess in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_SITE_ACCESS_COMBINATION")
	WebElement siteAccess_txtbox;

	public String getSiteAccess_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_SITE_ACCESS_COMBINATION")));
		String SiteAccess_txtbox= (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_SITE_ACCESS_COMBINATION")));
		return SiteAccess_txtbox;
	}

	public void setSiteAccess_txtbox(WebElement siteAccess_txtbox) {
		this.siteAccess_txtbox = siteAccess_txtbox;
	}
	/* This Method Is for getting SiteAccess in Detail Page  End*/

	/* This Method Is for getting OpertaionalArea in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_OPERATIONAL_AREA")
	WebElement opertaionalArea_txtbox;

	public String getOpertaionalArea_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_OPERATIONAL_AREA")));
		String OpertaionalArea_txtbox= (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_OPERATIONAL_AREA")));
		return OpertaionalArea_txtbox;
	}

	public void setOpertaionalArea_txtbox(WebElement opertaionalArea_txtbox) {
		this.opertaionalArea_txtbox = opertaionalArea_txtbox;
	}
	/* This Method Is for getting OpertaionalArea in Detail Page  End*/

	/* This Method Is for getting FieldTechnican in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_FIELD_OPERATIONS_TECHNICIAN")
	WebElement fieldTech_txtbox;

	public String getFieldTech_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_FIELD_OPERATIONS_TECHNICIAN")));
		String FieldTech_txtbox= (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_FIELD_OPERATIONS_TECHNICIAN")));
		return FieldTech_txtbox;
	}

	public void setFieldTech_txtbox(WebElement fieldTech_txtbox) {
		this.fieldTech_txtbox = fieldTech_txtbox;
	}
	/* This Method Is for getting FieldTechnican in Detail Page  End*/

	/* This Method Is for getting TerritorySupervisor in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_TERRITORY_SUPERVISOR")
	WebElement territorySupervisor_txtbox;

	public String getTerritorySupervisor_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_TERRITORY_SUPERVISOR")));
		String TerritorySupervisor_txtbox= (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_TERRITORY_SUPERVISOR")));
		return TerritorySupervisor_txtbox;
	}

	public void setTerritorySupervisor_txtbox(WebElement territorySupervisor_txtbox) {
		this.territorySupervisor_txtbox = territorySupervisor_txtbox;
	}
	/* This Method Is for getting TerritorySupervisor in Detail Page  End*/

	/* This Method Is for getting ROM in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_ROM")
	WebElement ROM_txtbox;

	public String getROM_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_ROM")));
		String ROM_txtbox= (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_ROM")));
		return ROM_txtbox;
	}

	public void setROM_txtbox(WebElement ROM_txtbox) {
		this.ROM_txtbox = ROM_txtbox;
	}
	/* This Method Is for getting ROM in Detail Page  End*/

	/* This Method Is for getting SpecialInstructions in Detail Page  Start*/
	@FindBy(id ="SITE_DETAILS_GENERAL_SITE_INFORMATION_SPECIAL_ACCESS_INSTRUCTIONS")
	WebElement specialInstructions_txtbox;

	public String getSpecialInstructions_txtbox() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_SPECIAL_ACCESS_INSTRUCTIONS")));
		String SpecialInstructions_txtbox= (String) ((JavascriptExecutor) selenium).executeScript("return arguments[0].value;",selenium.findElement(By.id("SITE_DETAILS_GENERAL_SITE_INFORMATION_SPECIAL_ACCESS_INSTRUCTIONS")));
		return SpecialInstructions_txtbox;
	}

	public void setSpecialInstructions_txtbox(WebElement specialInstructions_txtbox) {
		this.specialInstructions_txtbox = specialInstructions_txtbox;
	}
	/* This Method Is for getting SpecialInstructions in Detail Page  End*/

	/* This Method Is for Clicking SaveButton in Detail Page  Start*/
	@FindBy(xpath ="//*[@id=DETAILS]/div[2]/input")
	WebElement save_button;

	public WebElement getSave_button() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.className("save-button")));
		return save_button;
	}

	public void setSave_button(WebElement save_button) {
		this.save_button = save_button;
	}
	/* This Method Is for Clicking SaveButton in Detail Page  End*/

	/* This Method Is for Tower_DropDown in Detail Page  Start*/
	@FindBy(className ="tower-select")
	WebElement tower_dropdown;

	public WebElement getTower_dropdown() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.className("tower-select")));
		return tower_dropdown;
	}

	public void setTower_dropdown(WebElement tower_dropdown) {
		this.tower_dropdown = tower_dropdown;
	}
	/* This Method Is for Tower_DropDown in Detail Page  End*/

	/* This Method Is for Contactus_HyperLink in Detail Page  Start*/
	@FindBy(className ="user-section")
	WebElement contactus_hyperlink;

	public WebElement getContactus_hyperlink() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.className("user-section")));
		return contactus_hyperlink;
	}

	public void setContactus_hyperlink(WebElement contactus_hyperlink) {
		this.contactus_hyperlink = contactus_hyperlink;
	}
	/* This Method Is for Contactus_HyperLink in Detail Page  End*/

	/* This Method Is for Contactus_PhoneNumber in Detail Page  Start*/
	@FindBy(css ="html body div#alert-modal' and contains(text(),'Service Desk')]")
	WebElement contact_phonenumber;

	public WebElement getContact_phonenumber() {
		return contact_phonenumber;
	}

	public void setContact_phonenumber(WebElement contact_phonenumber) {
		this.contact_phonenumber = contact_phonenumber;
	}
	/* This Method Is for Contactus_PhoneNumber in Detail Page  End*/

	/* This Method Is for Contactus_Email in Detail Page  Start*/
	@FindBy(css ="html body div#alert-modal.modal div.msg-box a")
	WebElement contact_email;

	public WebElement getContact_email() {
		return contact_email;
	}

	public void setContact_email(WebElement contact_email) {
		this.contact_email = contact_email;
	}
	/* This Method Is for Contactus_Email in Detail Page  End*/

	/* This Method Is for Contactus_Regularhours in Detail Page  Start*/
	@FindBy(xpath ="//*[@id=#alert-modal]/div[1]/text()[2]")
	WebElement contact_regularhours;

	public WebElement getContact_regularhours() {
		return contact_regularhours;
	}

	public void setContact_regularhours(WebElement contact_regularhours) {
		this.contact_regularhours = contact_regularhours;
	}
	/* This Method Is for Contactus_Regularhours in Detail Page  End*/

	/* This Method Is for Contactus_OnCallhours in Detail Page  Start*/
	@FindBy(css ="html body div#alert-modal' and contains(text(),'Service Desk')]")
	WebElement contact_oncallhourshours;

	public WebElement getContact_oncallhourshours() {
		return contact_oncallhourshours;
	}

	public void setContact_oncallhourshours(WebElement contact_oncallhourshours) {
		this.contact_oncallhourshours = contact_oncallhourshours;
	}
	/* This Method Is for Contactus_OnCallhours in Detail Page  End*/

	/* This Method Is for Contactus_ok button in Detail Page  Start*/
	@FindBy(id ="alert-button")
	WebElement contact_okbutton;


	public WebElement getContact_okbutton() {
		return contact_okbutton;
	}

	public void setContact_okbutton(WebElement contact_okbutton) {
		this.contact_okbutton = contact_okbutton;
	}
	/* This Method Is for Contactus_ok button in Detail Page  end*/

	/* This Method Is for SiteNumber_Banner in Detail Page  Start*/
	@FindBy(id ="sitename_banner")
	WebElement sitename_banner;

	public WebElement getSitename_banner() {
		return sitename_banner;
	}

	public void setSitename_banner(WebElement sitename_banner) {
		this.sitename_banner = sitename_banner;
	}
	/* This Method Is for SiteNumber_Banner in Detail Page  End*/

	/* This Method Is for SiteName_Banner in Detail Page  Start*/
	@FindBy(id ="sitenumber_banner")
	WebElement sitenumber_banner;

	public WebElement getSitenumber_banner() {
		return sitenumber_banner;
	}

	public void setSitenumber_banner(WebElement sitenumber_banner) {
		this.sitenumber_banner = sitenumber_banner;
	}
	/* This Method Is for SiteName_Banner in Detail Page  End*/

	/* This Method Is for Top Button in Detail Page  Start*/
	@FindBy(id ="topButton")
	WebElement uparrow_button;

	public WebElement getUparrow_button() {
		return uparrow_button;
	}

	public void setUparrow_button(WebElement uparrow_button) {
		this.uparrow_button = uparrow_button;
	}
	/* This Method Is for Top Button in Detail Page  End*/

	/* This Method Is for Error Message Text for Required Fields in Detail Page  Start*/
	@FindBy(id ="alert-modal")
	WebElement requiredfield_message;

	public WebElement getRequiredfield_message() {
		return requiredfield_message;
	}

	public void setRequiredfield_message(WebElement requiredfield_message) {
		this.requiredfield_message = requiredfield_message;
	}
	/* This Method Is for Error Message Text for Required Fields in Detail Page  End*/

	/* This Method Is for Error Message ok Button for Required Fields in Detail Page  Start*/
	@FindBy(id ="alert-button")
	WebElement requiredfield_okbutton;

	public WebElement getRequiredfield_okbutton() {
		return requiredfield_okbutton;
	}

	public void setRequiredfield_okbutton(WebElement requiredfield_okbutton) {
		this.requiredfield_okbutton = requiredfield_okbutton;
	}
	/* This Method Is for Error Message ok Button for Required Fields in Detail Page  End*/

	/* This Method Is for successful save in Detail Page  Start*/
	@FindBy(id ="details-status")
	WebElement detailsstatus_color;

	public WebElement getDetailsstatus_color() {
		return detailsstatus_color;
	}

	public void setDetailsstatus_color(WebElement detailsstatus_color) {
		this.detailsstatus_color = detailsstatus_color;
	}
	/* This Method Is for successful save in Detail Page  End*/

	/* This Method Is for InspectionDetails Information circle in Detail Page  Start*/
	@FindBy(css ="html body div#amm-banner div#right div.site-section div.user-info-label.inspection-details i.fa.fa-info-circle.fa-fw")
	WebElement inspectiondetails_info;

	public WebElement getInspectiondetails_info() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("html body div#amm-banner div#right div.site-section div.user-info-label.inspection-details i.fa.fa-info-circle.fa-fw")));
		return inspectiondetails_info;
	}

	public void setInspectiondetails_info(WebElement inspectiondetails_info) {
		this.inspectiondetails_info = inspectiondetails_info;
	}
	/* This Method Is for InspectionDetails Information circle in Detail Page  End*/

	/* This Method Is for InspectionDetails_SiteVisitReason in Detail Page  Start*/
	@FindBy(id ="SITE_VISIT_REASON")
	WebElement inspection_sitevisitReason;

	public WebElement getInspection_sitevisitReason() {
		return inspection_sitevisitReason;
	}

	public void setInspection_sitevisitReason(WebElement inspection_sitevisitReason) {
		this.inspection_sitevisitReason = inspection_sitevisitReason;
	}
	/* This Method Is for InspectionDetails_SiteVisitReason in Detail Page  End*/

	/* This Method Is for InspectionDetails_InspectorName in Detail Page  Start*/
	@FindBy(id ="ON_VISIT_INSPECTOR_NAME")
	WebElement inspection_inspectorname;

	public WebElement getInspection_inspectorname() {
		return inspection_inspectorname;
	}

	public void setInspection_inspectorname(WebElement inspection_inspectorname) {
		this.inspection_inspectorname = inspection_inspectorname;
	}
	/* This Method Is for InspectionDetails_InspectorName in Detail Page  End*/

	/* This Method Is for InspectionDetails_AtcContractor in Detail Page  Start*/
	@FindBy(id ="ATC_OR_CONTRACTOR")
	WebElement inspection_atccontractor;

	public WebElement getInspection_atccontractor() {
		return inspection_atccontractor;
	}

	public void setInspection_atccontractor(WebElement inspection_atccontractor) {
		this.inspection_atccontractor = inspection_atccontractor;
	}
	/* This Method Is for InspectionDetails_AtcContractor in Detail Page  End*/

	/* This Method Is for InspectionDetails_LastDate in Detail Page  Start*/
	@FindBy(id ="LAST_INSPECTION_DATE")
	WebElement inspection_lastdate;

	public WebElement getInspection_lastdate() {
		return inspection_lastdate;
	}

	public void setInspection_lastdate(WebElement inspection_lastdate) {
		this.inspection_lastdate = inspection_lastdate;
	}
	/* This Method Is for InspectionDetails_LastDate in Detail Page  End*/
}
