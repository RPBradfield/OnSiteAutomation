package com.atc.online.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atc.online.common.BasePage;

public class JobSafety extends BasePage {

	public JobSafety(WebDriver selenium) {
		super(selenium);
		initialize(this);
	}

/* This Method Is for getting hazmat_checkbox in JobSafety Page  Start*/
@FindBy(id ="hazmat")
WebElement hazmat_checkbox ;

public WebElement getHazmat_checkbox() {
	return hazmat_checkbox;
}
public void setHazmat_checkbox(WebElement hazmat_checkbox) {
	this.hazmat_checkbox = hazmat_checkbox;
}
/* This Method Is for getting hazmat_checkbox in JobSafety Page  End*/

/* This Method Is for getting environmental_checkbox in JobSafety Page  Start*/
@FindBy(id ="environmental")
WebElement environmental_checkbox ;

public WebElement getEnvironmental_checkbox() {
	return environmental_checkbox;
}
public void setEnvironmental_checkbox(WebElement environmental_checkbox) {
	this.environmental_checkbox = environmental_checkbox;
}
/* This Method Is for getting environmental_checkbox in JobSafety Page  End*/

/* This Method Is for getting emergency_checkbox in JobSafety Page  Start*/
@FindBy(id ="emergency")
WebElement emergency_checkbox ;

public WebElement getEmergency_checkbox() {
	return emergency_checkbox;
}
public void setEmergency_checkbox(WebElement emergency_checkbox) {
	this.emergency_checkbox = emergency_checkbox;
}
/* This Method Is for getting emergency_checkbox in JobSafety Page  End*/

/* This Method Is for getting other_checkbox in JobSafety Page  Start*/
@FindBy(id ="other")
WebElement other_checkbox ;

public WebElement getOther_checkbox() {
	return other_checkbox;
}
public void setOther_checkbox(WebElement other_checkbox) {
	this.other_checkbox = other_checkbox;
}
/* This Method Is for getting other_checkbox in JobSafety Page  End*/

/* This Method Is for getting hazmat_dropdown in JobSafety Page  Start*/
@FindBy(id ="JOB_SAFETY_ANALYSIS_HAZMAT_HAZMAT_ON_SITE")
WebElement hazmat_dropdown ;

public WebElement getHazmat_dropdown() {
	return hazmat_dropdown;
}
public   void setHazmat_dropdown (String strValue) {
	Select dropdown = new Select(selenium.findElement(By.id("JOB_SAFETY_ANALYSIS_HAZMAT_HAZMAT_ON_SITE")));
	dropdown.selectByValue(strValue);
}

/* This Method Is for getting hazmat_dropdown in JobSafety Page  End*/

/* This Method Is for getting LocationHazmat in JobSafety Page  Start*/
@FindBy(id ="JOB_SAFETY_ANALYSIS_HAZMAT_HAZMAT_GROUP_0_MATERIAL_LOCATION")
WebElement LocationHazmat ;

public WebElement getLocationHazmat() {
	return LocationHazmat;
}
public void setLocationHazmat(WebElement locationHazmat) {
	LocationHazmat = locationHazmat;
}

/* This Method Is for getting LocationHazmat in JobSafety Page  End*/

//Class--ADC_INSPECTION validation controller-2--Hazmat Information

/* This Method Is for getting LocationHazmat in Container_TYPE  Start*/

@FindBy(className ="CONTAINER_TYPE_ID")
WebElement Container_TYPE ;

public WebElement getContainer_TYPE() {
	return Container_TYPE;
}
public void setContainer_TYPE( String strValue) {
		Select dropdown = new Select(selenium.findElement(By.className("CONTAINER_TYPE_ID")));
       	dropdown.selectByValue(strValue);
}
/* This Method Is for getting LocationHazmat in Container_TYPE  End*/


/* This Method Is for getting LocationHazmat in HAZMAT_TYPE  Start*/

@FindBy(className ="HAZMAT_TYPE_ID")
WebElement HAZMAT_TYPE ;

public WebElement getHAZMAT_TYPE() {
	return HAZMAT_TYPE;
}
public void setHAZMAT_TYPE( String strValue) {
	Select dropdown = new Select(HAZMAT_TYPE);
   	dropdown.selectByValue(strValue);
}

/* This Method Is for getting LocationHazmat in HAZMAT_TYPE  End*/
//
//Class--HAZMAT_TYPE_ID--HAZMAT_TYPE


/* This Method Is for getting LocationHazmat in HazmatNumberContainer  Start*/

@FindBy(id ="JOB_SAFETY_ANALYSIS_HAZMAT_HAZMAT_GROUP_0_CONTAINER_COUNT")
WebElement HazmatNumberContainer ;

public WebElement getHazmatNumberContainer() {
	return HazmatNumberContainer;
}
public void setHazmatNumberContainer(WebElement hazmatNumberContainer) {
	HazmatNumberContainer = hazmatNumberContainer;
}
/* This Method Is for getting LocationHazmat in HazmatNumberContainer  End*/


/* This Method Is for getting LocationHazmat in HazmatComment  Start*/

@FindBy(id ="JOB_SAFETY_ANALYSIS_HAZMAT_HAZMAT_GROUP_0_COMMENT")
WebElement HazmatComment ;

public WebElement getHazmatComment() {
	return HazmatComment;
}
public void setHazmatComment(WebElement hazmatComment) {
	HazmatComment = hazmatComment;
}

/* This Method Is for getting LocationHazmat in HazmatComment  End*/

/* This Method Is for getting LocationHazmat in HazmatAdd_button  Start*/

@FindBy(id ="JOB_SAFETY_ANALYSIS_HAZMAT_HAZMAT_GROUP_0_ADD_BUTTON")
WebElement HazmatAdd_button ;

public WebElement getHazmatAdd_button() {
	return HazmatAdd_button;
}
public void setHazmatAdd_button(WebElement hazmatAdd_button) {
	HazmatAdd_button = hazmatAdd_button;
}

/* This Method Is for getting LocationHazmat in HazmatAdd_button  End*/

/* This Method Is for getting LocationHazmat in ConversionChart_Link  Start*/

@FindBy(partialLinkText ="Conversion")
WebElement ConversionChart_Link ;

public WebElement getConversionChart_Link() {
	JavascriptExecutor executor = (JavascriptExecutor)selenium;
	executor.executeScript("arguments[0].click();", ConversionChart_Link);
	return ConversionChart_Link;
}
public void setConversionChart_Link(WebElement conversionChart_Link) {
	ConversionChart_Link = conversionChart_Link;
}
/* This Method Is for getting LocationHazmat in ConversionChart_Link  End*/


}
