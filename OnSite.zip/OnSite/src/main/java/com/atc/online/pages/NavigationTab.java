package com.atc.online.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.atc.online.common.BasePage;

public class NavigationTab extends BasePage{

	public NavigationTab(WebDriver selenium) {
		super(selenium);
		initialize(this);
		// TODO Auto-generated constructor stub
	}

	@FindBy(id ="dd-sd")
	WebElement Detail_tab;

	public WebElement getDetail_tab() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOf(Detail_tab));
		return Detail_tab;
	}

	public void setDetail_tab(WebElement detail_tab) {
		Detail_tab = detail_tab;
	}

	@FindBy(id ="dd-as")
	WebElement dashBoard_tab;

	public WebElement getDashBoard_tab() {
		BasePage.getWebDriverWait(10000).until(ExpectedConditions.visibilityOf(dashBoard_tab));
		return dashBoard_tab;
	}

	public void setDashBoard_tab(WebElement dashBoard_tab) {
		this.dashBoard_tab = dashBoard_tab;
	}

	@FindBy(id ="job-safety-status")
	WebElement JobSafety_tab;

	public WebElement getJobSafety_tab() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOf(JobSafety_tab));
		return JobSafety_tab;
	}

	public void setJobSafety_tab(WebElement jobSafety_tab) {
		JobSafety_tab = jobSafety_tab;
	}

	@FindBy(id ="dd-ut")
	WebElement Utilities_tab;

	public WebElement getUtilities_tab() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOf(Utilities_tab));
		return Utilities_tab;
	}

	public void setUtilities_tab(WebElement utilities_tab) {
		Utilities_tab = utilities_tab;
	}

	@FindBy(id ="dd-sa")
	WebElement Assets_tab;

	public WebElement getAssets_tab() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOf(Assets_tab));
		return Assets_tab;
	}

	public void setAssets_tab(WebElement assets_tab) {
		Assets_tab = assets_tab;
	}

	@FindBy(id ="dd-atc")
	WebElement MonitoredEquip_tab;

	public WebElement getMonitoredEquip_tab() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOf(MonitoredEquip_tab));
		return MonitoredEquip_tab;
	}

	public void setMonitoredEquip_tab(WebElement monitoredEquip_tab) {
		MonitoredEquip_tab = monitoredEquip_tab;
	}

	@FindBy(id ="dd-tge")
	WebElement TenantGround_tab;

	public WebElement getTenantGround_tab() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOf(TenantGround_tab));
		return TenantGround_tab;
	}

	public void setTenantGround_tab(WebElement tenantGround_tab) {
		TenantGround_tab = tenantGround_tab;
	}

	@FindBy(className ="tower-page-item")
	WebElement Tower_tab;

	public WebElement getTower_tab() {
		BasePage.getWebDriverWait(1000).until(ExpectedConditions.visibilityOf(Tower_tab));
		return Tower_tab;
	}

	public void setTower_tab(WebElement tower_tab) {
		Tower_tab = tower_tab;
	}
}
