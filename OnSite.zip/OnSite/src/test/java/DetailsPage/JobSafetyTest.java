package DetailsPage;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.atc.online.common.BasePage;
import com.atc.online.pages.DashboardPage;
import com.atc.online.pages.JobSafety;
import com.atc.online.pages.LoginPage;
import com.atc.online.pages.NavigationTab;



	public class JobSafetyTest {
		@Test
		public void DetailsFMWTest() throws Exception  {

			LoginPage Login = new LoginPage(null);
			Login.loginCredential();
			WebDriver selenium = BasePage.getDriver();
			DashboardPage dashboardPage =new DashboardPage(selenium);
			String A = BasePage.getdata("Data","TC_No4","SiteNumber");
			dashboardPage.getSearchText_Box().sendKeys(A);
			dashboardPage.getSearch_btn().click();
			dashboardPage.getSelect_checkbox().click();
			dashboardPage.getSaveSiteLocally().click();
			Thread.sleep(1000);
			dashboardPage.getAlertOk_button().click();
			dashboardPage.getClickSiteNumber_link().click();
			NavigationTab Navigate = new NavigationTab(selenium);
			Navigate.getJobSafety_tab().click();
			JobSafety JobSafety = new JobSafety(selenium);
			JobSafety.getHazmat_checkbox().click();
			JobSafety.getEnvironmental_checkbox().click();
			JobSafety.getEmergency_checkbox().click();
			JobSafety.getOther_checkbox().click();
			JobSafety.getHazmat_checkbox().click();
			JobSafety.getEnvironmental_checkbox().click();
			JobSafety.getEmergency_checkbox().click();
			JobSafety.getOther_checkbox().click();
			JobSafety.setHazmat_dropdown("Yes");
			JobSafety.getLocationHazmat().sendKeys("Test");
			JobSafety.setContainer_TYPE("Bucket");
			JobSafety.setHAZMAT_TYPE("Paint");
			JobSafety.getHazmatNumberContainer().sendKeys("1");
			JobSafety.getHazmatComment().sendKeys("Test");
			Thread.sleep(1000);
		
			JobSafety.getConversionChart_Link();
			String XA=	selenium.getTitle();
			/* This Method Code for Navigating Back to current Tab*/
			selenium.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"\t");
			selenium.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"\t");
			
	         String XAq=	selenium.getTitle();
			System.out.println(XA);
			System.out.println(XAq);

		}

	}



