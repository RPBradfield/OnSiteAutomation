package DetailsPage;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.atc.online.common.BasePage;
import com.atc.online.pages.DashboardPage;
import com.atc.online.pages.LoginPage;
import com.atc.online.pages.DetailsPage;

public class DetailsPage_ContactusTest {

	@Test
	public void detailsContactusTest() throws Exception  {
		String A = BasePage.getdata("Data","TC_No3","SiteNumber");
		LoginPage Login = new LoginPage(null);
		Login.loginCredential();
		WebDriver selenium = BasePage.getDriver();
		DashboardPage dashboardPage =new DashboardPage(selenium);
		DetailsPage details = new DetailsPage(selenium);
		dashboardPage.getSearchText_Box().sendKeys(A);
		dashboardPage.getSearch_btn().click();
		dashboardPage.getSelect_checkbox().click();
		dashboardPage.getSaveSiteLocally().click();
		Thread.sleep(1000);
		dashboardPage.getAlertOk_button().click();
		dashboardPage.getClickSiteNumber_link().click();
		details.getContactus_hyperlink().click();
		//String phonenumber= details.getContact_phonenumber().getText();
		String phonenumber=  selenium.findElement(By.xpath("//div[@class='msg-box'][contains(.,'Service Desk')]")).getText();
		//label[//text()[normalize-space() = 'some label']]
		details.getContact_okbutton().click();
		String Contact_oncallhours= 	details.getContact_oncallhourshours().getText();
		String Contact_phonenumber= 	details.getContact_phonenumber().getText();
		String Contact_regularhours= 	details.getContact_regularhours().getText();
		System.out.println(Contact_oncallhours);
		System.out.println(Contact_phonenumber);
		System.out.println(Contact_regularhours);
		System.out.println("this is for number:"+ phonenumber);
	}
	
	@AfterMethod
	public void ClosingTest5() throws IOException  {
		WebDriver selenium = BasePage.getDriver();
		DashboardPage dashboardPage =new DashboardPage(selenium);
		dashboardPage.getDashBoard_tab().click();
		dashboardPage.getLogout().click();
		selenium.quit();
	}
}

