
package DetailsPage;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.atc.online.common.BasePage;
import com.atc.online.pages.DashboardPage;
import com.atc.online.pages.LoginPage;
import com.atc.online.pages.DetailsPage;


public class DetailsPage_InspectionTest {

	@Test
	public void DetailsInspectionTest() throws Exception  {
		String A = BasePage.getdata("Data","TC_No5","SiteNumber");
		LoginPage Login = new LoginPage(null);
		Login.loginCredential();
		WebDriver selenium = BasePage.getDriver();
		DashboardPage dashboardPage =new DashboardPage(selenium);
		DetailsPage details = new DetailsPage(selenium);
		dashboardPage.getSearchText_Box().sendKeys(A);
		dashboardPage.getSearch_btn().click();
		dashboardPage.getSelect_checkbox().click();
		dashboardPage.getSaveSiteLocally().click();
		Thread.sleep(1000);
		dashboardPage.getAlertOk_button().click();
		dashboardPage.getClickSiteNumber_link().click();
		details.getInspectiondetails_info().click();
		String Inspection_atccontractor= details.getInspection_atccontractor().getText();
		String Inspection_inspectorname= 	details.getInspection_inspectorname().getText();
		String Inspection_lastdate= 	details.getInspection_lastdate().getText();
		String Inspection_sitevisitReason= 	details.getInspection_sitevisitReason().getText();
		System.out.println(Inspection_atccontractor);
		System.out.println(Inspection_inspectorname);
		System.out.println(Inspection_lastdate);
		System.out.println(Inspection_sitevisitReason);
	}
	@AfterMethod
	public void ClosingTest3() throws IOException  {

		WebDriver selenium = BasePage.getDriver();
		DashboardPage dashboardPage =new DashboardPage(selenium);
		dashboardPage.getDashBoard_tab().click();
		dashboardPage.getLogout().click();
		selenium.quit();

	}



}

