
package DetailsPage;


import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.atc.online.common.BasePage;
import com.atc.online.pages.DashboardPage;
import com.atc.online.pages.LoginPage;
import com.atc.online.pages.DetailsPage;
import com.atc.online.utils.DBQuery;

public class DetailsPage_SiteDetailsFMWTest {
	@Test
	public void DetailsFMWTest() throws Exception  {

		LoginPage Login = new LoginPage(null);
		Login.loginCredential();
		WebDriver selenium = BasePage.getDriver();
		DashboardPage dashboardPage =new DashboardPage(selenium);
		String A = BasePage.getdata("Data","TC_No4","SiteNumber");
		dashboardPage.getSearchText_Box().sendKeys(A);
		dashboardPage.getSearch_btn().click();
		dashboardPage.getSelect_checkbox().click();
		dashboardPage.getSaveSiteLocally().click();
		Thread.sleep(1000);
		dashboardPage.getAlertOk_button().click();
		dashboardPage.getClickSiteNumber_link().click();
		DetailsPage details = new DetailsPage(selenium);
		DBQuery query = new DBQuery();
		String B = BasePage.getdata("Data","TC_No4","sqlquery");
		String sitenumber = details.getSiteNumber_txtbox();
		String SITE_NUMBER_DB = query.DI(B).getString(1);
		String Address_911 = details.getAddress_911txtbox();
		String Address_911_DB = query.DI(B).getString(2);
		String site_access = details.getSiteAccess_txtbox();
		String site_access_DB = query.DI(B).getString(3);
		String special_access_instruct = details.getSpecialInstructions_txtbox();
		String special_access_instruct_DB = query.DI(B).getString(5);
		String FOT = details.getFieldTech_txtbox();
		String FOT_DB= query.DI(B).getString(6);
		String TS = details.getTerritorySupervisor_txtbox();
		String TS_DB = query.DI(B).getString(7);
		String ROM = details.getROM_txtbox();
		String ROM_DB = query.DI(B).getString(8);
		Assert.assertEquals(sitenumber, SITE_NUMBER_DB, "pass");
		Assert.assertEquals(Address_911, Address_911_DB, "pass");
		Assert.assertEquals(site_access, site_access_DB, "pass");
		Assert.assertEquals(special_access_instruct, special_access_instruct_DB, "pass");
		Assert.assertEquals(FOT, FOT_DB, "pass");
		Assert.assertEquals(TS, TS_DB, "pass");
		Assert.assertEquals(ROM, ROM_DB, "pass");
		System.out.println(ROM_DB);
		System.out.println(Address_911_DB);
		System.out.println(site_access_DB);
		System.out.println(special_access_instruct_DB);
		System.out.println(FOT_DB);
		System.out.println(TS_DB);

	}

	@AfterMethod
	public void closingTest1() throws Exception{
		DBQuery query = new DBQuery();
		WebDriver selenium = BasePage.getDriver();
		DashboardPage dashboardPage =new DashboardPage(selenium);
		String B = BasePage.getdata("Data","TC_No3","sqlquery");
		query.DI(B).close();
		dashboardPage.getDashBoard_tab().click();
		dashboardPage.getLogout().click();
		selenium.quit();
	}

}


