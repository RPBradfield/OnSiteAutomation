
package DetailsPage;


import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.atc.online.common.BasePage;
import com.atc.online.pages.DashboardPage;
import com.atc.online.pages.LoginPage;
import com.atc.online.pages.DetailsPage;
import com.atc.online.utils.DBQuery;

public class DetailsPage_SiteDetailsDITest {

	@Test
	public void DetailsDITest() throws Exception  {
		String A = BasePage.getdata("Data","TC_No3","SiteNumber");
		LoginPage Login = new LoginPage(null);
		Login.loginCredential();
		WebDriver selenium = BasePage.getDriver();
		DashboardPage dashboardPage =new DashboardPage(selenium);
		dashboardPage.getSearchText_Box().sendKeys(A);
		dashboardPage.getSearch_btn().click();
		dashboardPage.getSelect_checkbox().click();
		dashboardPage.getSaveSiteLocally().click();
		Thread.sleep(1000);
		dashboardPage.getAlertOk_button().click();
		dashboardPage.getClickSiteNumber_link().click();
		DetailsPage details = new DetailsPage(selenium);
		DBQuery query = new DBQuery();
		String B = BasePage.getdata("Data","TC_No3","sqlquery");
		String sitenumber = details.getSiteNumber_txtbox();
		String SITE_NUMBER_DB = query.DI(B).getString(1);
		String siteName = details.getSiteName_txtbox();
		String SITE_NAME_DB = query.DI(B).getString(2);
		String Address = details.getAddress_txtbox();
		String AddreeLine1_DB = query.DI(B).getString(3);
		String CITY = details.getCity_txtbox();
		String CITY_DB = query.DI(B).getString(4);
		String STATE = details.getState_txtbox();
		String STATE_DB = query.DI(B).getString(5);
		String zipcode = details.getZipcode_txtbox();
		String POSTAL_CODE_DB= query.DI(B).getString(6);
		String COUNTY = details.getCounty_txtbox();
		String COUNTY_DB = query.DI(B).getString(7);
		String DRIVING_DIRECTIONS = details.getDrivingDirections_txtbox();
		String DRIVING_DIRECTIONS_DB = query.DI(B).getString(8);
		String sitenumber_banner =  details.getSitenumber_banner().getText();
		String sitename_banner =  details.getSitename_banner().getText();
		Assert.assertEquals(sitenumber, SITE_NUMBER_DB, "pass");
		Assert.assertEquals(siteName, SITE_NAME_DB, "pass");
		Assert.assertEquals(Address, AddreeLine1_DB, "pass");
		Assert.assertEquals(CITY, CITY_DB, "pass");
		Assert.assertEquals(STATE, STATE_DB, "pass");
		Assert.assertEquals(zipcode, POSTAL_CODE_DB, "pass");
		Assert.assertEquals(COUNTY, COUNTY_DB, "pass");
		Assert.assertEquals(DRIVING_DIRECTIONS, DRIVING_DIRECTIONS_DB, "pass");
		Assert.assertEquals(sitenumber_banner, SITE_NUMBER_DB, "pass");
		Assert.assertEquals(sitename_banner, SITE_NAME_DB, "pass");
	}

	@AfterMethod
	public void ClosingTest2() throws Exception {
		DBQuery query = new DBQuery();
		WebDriver selenium = BasePage.getDriver();
		DashboardPage dashboardPage =new DashboardPage(selenium);
		String B = BasePage.getdata("Data","TC_No3","sqlquery");
		query.DI(B).close();
		dashboardPage.getDashBoard_tab().click();
		dashboardPage.getLogout().click();
		selenium.quit();

	}

}

