/*
package SampleTest;

import org.testng.annotations.Test;
import com.atc.online.common.BasePage;
import com.atc.online.utils.DBQuery;


public class ExcelTest {

	@Test
	public void bxcelTest() throws Exception   {

		String A = BasePage.getdata("Data","TC_No1","SiteNumber");
		String B = BasePage.getdata("Data","TC_No4","sql query");
		System.out.println(A);
		System.out.println(B);
		DBQuery query = new DBQuery();
//		int Project_number= query.DI("SELECT SITE_NUMBER, SITE_NAME, ADDRESS_LINE1, CITY, STATE, POSTAL_CODE, COUNTY FROM US_ODS.SITE where PROJECT_NUMBER= '11691357'").getInt(3);
//		String PROJECT_NAME= query.DI("select PROJECT_NAME,PROJECT_TEMPLATE_NAME,PROJECT_NUMBER from US_ODS.PROJECT where PROJECT_NUMBER= '11691357'").getString(1);
//		System.out.println("this is Project_number Value:" + Project_number);
//		System.out.println("this is PROJECT_NAME Value:" + PROJECT_NAME);
//		query.DI("select PROJECT_NAME,PROJECT_TEMPLATE_NAME,PROJECT_NUMBER from US_ODS.PROJECT where PROJECT_NUMBER= '11691357'").close();
        String address911 = query.FMW(B).getString(2) ;	
        String SITE_ACCESS = query.FMW(B).getString(3) ;
        System.out.println("This is Value of address911:"+address911);
        System.out.println("This is Value of SITE_ACCESS:"+SITE_ACCESS); 
	}

}
 */
