/*
package SampleTest;


import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import com.atc.online.common.BasePage;
import com.atc.online.pages.DashboardPage;
import com.atc.online.pages.LoginPage;
import com.atc.online.pages.DetailsPage;

public class clickTest {

	@Test
	public void SiteNameTest() throws Exception  {
		String A = BasePage.getdata("Data","TC_No2","SiteNumber");

		LoginPage Login = new LoginPage(null);
		Login.loginCredential();

		WebDriver selenium = BasePage.getDriver();
		DashboardPage dashboardPage =new DashboardPage(selenium);
		DetailsPage details = new DetailsPage(selenium);
		dashboardPage.getSearchText_Box().sendKeys(A);
		dashboardPage.getSearch_btn().click();
		dashboardPage.getSelect_checkbox().click();
		dashboardPage.getSaveSiteLocally().click();
		Thread.sleep(10000);
		dashboardPage.getAlertOk_button().click();
		dashboardPage.getClickSiteNumber_link().click();
		details.getDrivingDirections_write().sendKeys("bank");
		Thread.sleep(1000);
        details.getDrivingDirections_write().clear();
        Thread.sleep(10000);
		details.getSave_button().click();
		Thread.sleep(10000);
//		String Q = details.getRequiredfield_message().getText();
//		details.getRequiredfield_okbutton().click();
//		details.getInspectiondetails_info().click();
//		String c = details.getInspection_atccontractor().getText();
//		String V = details.getInspection_inspectorname().getText();
//		String n = details.getInspection_sitevisitReason().getText();
//		String X = details.getInspection_lastdate().getText();
//		System.out.println(Q);
//		System.out.println(c);
//		System.out.println(V);
//		System.out.println(n);
//		System.out.println(X);
//		dashboardPage.getDashBoard_tab().click();
//		dashboardPage.getLogout().click();
//		selenium.close();
		}

}
 */