package Login;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import com.atc.online.common.BasePage;
import com.atc.online.pages.DashboardPage;
import com.atc.online.pages.LoginPage;
import com.atc.online.pages.NavigationTab;

public class NavigationTest {

	@Test
	public void NavigateTabsTest() throws IOException, InterruptedException  {

		LoginPage Login = new LoginPage(null);
		Login.loginCredential();

		WebDriver selenium = BasePage.getDriver();
		DashboardPage dashboardPage =new DashboardPage(selenium);
		dashboardPage.getSearchText_Box().sendKeys("311744");
		dashboardPage.getSearch_btn().click();
		dashboardPage.getSelect_checkbox().click();
		dashboardPage.getSaveSiteLocally().click();
		Thread.sleep(10000);
		dashboardPage.getAlertOk_button().click();
		dashboardPage.getClickSiteNumber_link().click();
		Thread.sleep(1000);
		NavigationTab navigate = new NavigationTab(selenium);
		navigate.getJobSafety_tab().click();
		Thread.sleep(1000);
		navigate.getMonitoredEquip_tab().click();
		Thread.sleep(1000);
		navigate.getTenantGround_tab().click();
		Thread.sleep(1000);
		navigate.getTower_tab().click();
		Thread.sleep(1000);
		navigate.getUtilities_tab().click();
		Thread.sleep(1000);
		navigate.getDetail_tab().click();
		Thread.sleep(1000);
		navigate.getDashBoard_tab().click();
		Thread.sleep(1000);
		dashboardPage.getLogout().click();
		selenium.close();

	}

}
