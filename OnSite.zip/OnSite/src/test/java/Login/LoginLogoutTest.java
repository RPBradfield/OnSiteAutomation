
package Login;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.atc.online.common.BasePage;
import com.atc.online.pages.DashboardPage;
import com.atc.online.pages.LoginPage;

public class LoginLogoutTest {

	@Test
	public void loginAppTest() {

	}

	@ BeforeMethod
	public void login() throws Exception
	{
		//WebDriver selenium = BasePage.getDriver();
		LoginPage Login = new LoginPage(null);
		Login.loginCredential();
	}

	@AfterMethod
	public void logout() throws IOException, InterruptedException
	{
		WebDriver selenium = BasePage.getDriver();
		DashboardPage dashboardPage =new DashboardPage(selenium);
		dashboardPage.getSearchText_Box().sendKeys("311744");
		dashboardPage.getSearch_btn().click();
		dashboardPage.getSelect_checkbox().click();
		dashboardPage.getSaveSiteLocally().click();
		Thread.sleep(10000);
		dashboardPage.getAlertOk_button().click();
		dashboardPage.getClickSiteNumber_link().click();
		dashboardPage.getDashBoard_tab().click();
		dashboardPage.getLogout().click();
		selenium.close();
	}

}

